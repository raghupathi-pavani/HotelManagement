package com.org.hbms.service;

import java.sql.SQLException;

import com.org.hbms.bean.HBMSbean;
import com.org.hbms.dao.HBMSDaoImpl;
import com.org.hbms.dao.IHBMSDao;
import com.org.hbms.exception.HBMSException;

public class HBMSserviceImpl implements IHBMSservice{

	@Override
	public int registerUser(HBMSbean b) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.registerUser(b);		
	}

	@Override
	public boolean validateUserLogin(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.validateUserLogin(username,password);
	}

	@Override
	public StringBuilder getHotelDetails() throws HBMSException{
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getHotelDetails();
	}

	@Override
	public HBMSbean getUserDetails(String username, String password) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.getUserDetails(username,password);
	}

	@Override
	public boolean isValidPassword(String rPassword) {
		int length=rPassword.length();
		if(length>7 && length<0)
		{
			return false;
		}
		return true;
	}

	@Override
	public StringBuilder displayRooms(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.displayRooms(hotel_id);
	}

	@Override
	public boolean isValidHotelId(String hotel_id) throws HBMSException {
		IHBMSDao d1=new HBMSDaoImpl();
		return d1.isValidHotelId(hotel_id);
	}

	@Override
	public boolean validateAdminLogin(String username, String password) {
		if(username.equals("admin") && password.equals("admin"))
		{
			return true;
		}
		return false;
	}

}
