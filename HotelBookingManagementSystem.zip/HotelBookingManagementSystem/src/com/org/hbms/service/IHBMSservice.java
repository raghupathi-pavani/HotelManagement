package com.org.hbms.service;

import java.sql.SQLException;

import com.org.hbms.bean.HBMSbean;
import com.org.hbms.exception.HBMSException;

public interface IHBMSservice {

	int registerUser(HBMSbean b) throws HBMSException;

	boolean validateUserLogin(String username, String password) throws HBMSException;

	StringBuilder getHotelDetails() throws HBMSException;

	HBMSbean getUserDetails(String username, String password) throws HBMSException;

	boolean isValidPassword(String rPassword);

	StringBuilder displayRooms(String hotel_id) throws HBMSException;

	boolean isValidHotelId(String hotel_id) throws HBMSException;

	boolean validateAdminLogin(String username, String password);

}
