package com.org.hbms.dao;

import java.sql.SQLException;

import com.org.hbms.bean.HBMSbean;
import com.org.hbms.exception.HBMSException;

public interface IHBMSDao{

	int registerUser(HBMSbean b) throws HBMSException;

	boolean validateUserLogin(String username, String password) throws HBMSException;

	StringBuilder getHotelDetails() throws HBMSException;

	HBMSbean getUserDetails(String username, String password) throws HBMSException;

	StringBuilder displayRooms(String hotel_id) throws HBMSException;

	boolean isValidHotelId(String hotel_id) throws HBMSException;

}
