package com.org.hbms.dao;

public interface IQueryMapper {
	String userRegisterQuery="insert into Users values(?,?,?,?,?,?,?,?)";
	String userValidQuery="select count(*) from users where user_name=? and password=?";
	String hotelDetailsQuery="select * from hotel";
	String userIdQuery = "select user_id_seq.nextval from dual";
	String getRoleQuery = "select * from Users where user_name=? and password=?";
	String displayRoomQuery = "select * from roomdetails";
	String validHotelQuery = "select count(*) from hotel where hotel_id=?";
}
